import Vue from 'vue';

window.Event = new Vue();

export default new Vue();