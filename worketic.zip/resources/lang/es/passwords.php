<?php 

return [
    'password' => 'Las contraseñas deben tener al menos seis caracteres y coincidir con la confirmación.',
    'reset' => '¡Tu contraseña ha sido restablecida!',
    'sent' => '¡Hemos enviado por correo electrónico el enlace para restablecer su contraseña!',
    'token' => 'Este token de restablecimiento de contraseña no es válido.',
    'user' => 'No podemos encontrar un usuario con esa dirección de correo electrónico.',
];