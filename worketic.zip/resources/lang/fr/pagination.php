<?php 

return [
    'previous' => '& laquo; précédent',
    'next' => 'Suivant & raquo;',
];