<?php

return [
    'secret' => '6LeWsasUAAAAAOAgl3oiHowPaX3_NHNJor87rqlw',
    'sitekey' => '6LeWsasUAAAAAC9yZpUNPNamlF-BSP2R6BJgAxNK',
    'options' => [
        'timeout' => 30,
    ],
];
