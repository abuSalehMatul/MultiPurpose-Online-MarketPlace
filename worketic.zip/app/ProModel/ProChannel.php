<?php

namespace App\ProModel;

use Illuminate\Database\Eloquent\Model;

class ProChannel extends Model
{
    //
}
