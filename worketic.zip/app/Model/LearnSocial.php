<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class LearnSocial extends Model
{
    protected $table = 'learn_socials';
    protected $guarded = [''];
}
