<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class LearnSlider extends Model
{
    protected $guarded = [];
}
