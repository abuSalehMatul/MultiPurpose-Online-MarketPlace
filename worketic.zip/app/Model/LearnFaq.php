<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class LearnFaq extends Model
{
   // protected $table = 'learn_faqs';
    protected $guarded = [];
}
