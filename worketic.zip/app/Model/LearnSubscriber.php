<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class LearnSubscriber extends Model
{
    protected $table = "learn_subscribers";

    protected  $guarded = [];
}
