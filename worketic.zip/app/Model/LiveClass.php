<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class LiveClass extends Model
{
    protected $guarded = [];
    protected $dates = [];
    protected $table = "live_classes";
}
