<?php

namespace App\JobModel;

use Illuminate\Database\Eloquent\Model;

class JobChannel extends Model
{
    //
}
