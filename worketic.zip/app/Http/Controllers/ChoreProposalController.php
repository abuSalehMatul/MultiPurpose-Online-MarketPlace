<?php

namespace App\Http\Controllers;

use App\Chore_proposal;
use Illuminate\Http\Request;

class ChoreProposalController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Chore_proposal  $chore_proposal
     * @return \Illuminate\Http\Response
     */
    public function show(Chore_proposal $chore_proposal)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Chore_proposal  $chore_proposal
     * @return \Illuminate\Http\Response
     */
    public function edit(Chore_proposal $chore_proposal)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Chore_proposal  $chore_proposal
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Chore_proposal $chore_proposal)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Chore_proposal  $chore_proposal
     * @return \Illuminate\Http\Response
     */
    public function destroy(Chore_proposal $chore_proposal)
    {
        //
    }
}
