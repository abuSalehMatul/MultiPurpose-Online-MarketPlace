<?php
/**
 * Class EmailTemplateController.
 *
 * @category Worketic
 *
 * @package Worketic
 * @author  Amentotech <theamentotech@gmail.com>
 * @license http://www.amentotech.com Amentotech
 * @link    http://www.amentotech.com
 */
namespace App\Http\Controllers\Pro;

use App\EmailTemplate;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use View;
use Session;
use App\ProModel\ProHelper;

/**
 * Class EmailTemplateController
 *
 */
class ProEmailTemplateController extends Controller
{
    /**
     * Defining scope of the variable
     *
     * @access protected
     * @var    array $email
     */
    protected $email;

    /**
     * Create a new controller instance.
     *
     * @param instance $email instance
     *
     * @return void
     */
    public function __construct(EmailTemplate $email)
    {
        $this->email = $email;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (!empty($_GET['keyword'])) {
            $keyword = $_GET['keyword'];
            $templates = $this->email::where('title', 'like', '%' . $keyword . '%')->paginate(7)->setPath('');
            $pagination = $templates->appends(
                array(
                    'keyword' => Input::get('keyword')
                )
            );
        } else {
            $templates = $this->email->getEmailTemplates();
        }
        return View::make('pro.back-end.admin.email-templates.index', compact('templates'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id ID
     *
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $template = $this->email::getEmailTemplateByID($id);
        return View::make('pro.back-end.admin.email-templates.edit', compact('template'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request request
     * @param \App\EmailTemplate       $id      emailTemplate
     *
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $server_verification = ProHelper::worketicIsDemoSite();
        if (!empty($server_verification)) {
            Session::flash('error', $server_verification);
            return Redirect::to('admin/email-templates');
        }
        $this->validate(
            $request, [
                'title' => 'required',
                'subject' => 'required',
                'email_content' => 'required',
            ]
        );
        $this->email->updateEmailTemplates($request, $id);
        Session::flash('message', trans('lang.email_template_updated'));
        return Redirect::to('admin/email-templates');
    }
}
